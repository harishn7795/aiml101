sudo apt-get install python3
sudo apt-get install python3-pip
sudo apt-get install ipython3
sudo apt-get install jupyter

pip3 install jupyter
pip  install pandas
pip  install scikit-learn


jupyter notebook --allow-root
